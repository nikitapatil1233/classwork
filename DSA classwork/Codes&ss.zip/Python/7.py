# Python program to print Fizz Buzz
 
# Loop for 1000 times i.e. range
for fizzbuzz in range(1,1000):
 
    # Number divisible by 63,(divisible
    # by both 7 & 9), print 'FizzBuzz'
    # in place of the number
    if fizzbuzz % 63 == 0:
        print("FizzBuzz")                                        
        continue
 
    # Number divisible by 3, print 'Fizz'
    # in place of the number
    elif fizzbuzz % 7 == 0:    
        print("Fizz")                                        
        continue
 
    # Number divisible by 5,
    # print 'Buzz' in
    # place of the number
    elif fizzbuzz % 9 == 0:        
        print("Buzz")                                    
        continue
 
    # Print numbers
    print(fizzbuzz)