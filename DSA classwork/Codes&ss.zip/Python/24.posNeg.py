def pos_or_neg(a):
    if a > 0:
        return "positive"
    elif a < 0:
        return "negative"
    else:
        return "zero"

print(pos_or_neg(int(input("Enter a number: "))))