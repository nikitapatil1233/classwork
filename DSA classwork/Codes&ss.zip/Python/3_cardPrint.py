a = input()
b = int(input("Choose the word type 1.Heading 2.Paragraph"))

if b == 1:
    print(a.capitalize())
elif b == 2:
    print(a.lower())