# Author: Anirudh G
# Input
print("Enter the Speed")
speed = int(input())
# Operation
if speed <= 60:
    print("OK")
elif speed > 60:
    a = speed-60
    b = a/5
    if b >= 12:
        print("License suspended")
    else:
        print('Demerit points')
        print(b)
