# Author: Anirudh G
# Code to identify square numbers
import math
# Taking the input from user
lim = int(input("Enter the limit"))
# for greater than six
if lim > 6:
    print('Numbers from 0 to', lim, 'to be checked')
    print('0 NA')
    count = 1
    while (count < (lim+1)):
        ans = math.sqrt(count)
        if int(ans + 0.5) ** 2 == count:
            print(count, "Sq No")
        else:
            print(count, "NOT a Sq No")
        count = count+1

# for less than six
elif lim <= 6:
    print('Enter a valid no to be checked')
