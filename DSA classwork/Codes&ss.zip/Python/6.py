# Author: Anirudh G
file = open('file.txt', 'r')
list1 = []
while 1:
    # read by character
    char = file.read(1)
    if not char:
        break
    list1.append(int(char))
file.close()
list2 = []
n = len(list1)
sum = 0
if n < 5:
    for i in list1:
        sum += (i/n)
    print(sum)
else:
    for i in range(len(list1)):
        for j in range(i, (i+4)):
            sum += (list1[j]/5)
        list2.append(sum)
        sum = 0
    y = max(list2)
    print(y)
