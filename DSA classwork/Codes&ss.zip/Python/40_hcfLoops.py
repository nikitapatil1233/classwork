# Write a python program to find the H.C.F of two input number using loops


def hcf_loops(x,y):

    if x>y:
        small = y
    else:
        small = x

    for i in range(1, small+1):
        if (x%i == 0) and (y%i==0):
            hcf = i

    return hcf

result = hcf_loops(21,63)
print(result)