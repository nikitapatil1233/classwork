38. Answer the following
1). What is SCipy?
SciPy, a scientific library for Python is an open source, BSD-licensed library for mathematics,
science and engineering. The SciPy library depends on NumPy, which provides convenient and fast N-dimensional
array manipulation. The main reason for building the SciPy library is that, it should work with NumPy arrays.
It provides many user-friendly and efficient numerical practices such as routines for numerical integration
and optimization.

Difference between Scipy and Numpy?
NumPy is basically for basic operations such as sorting, indexing, and elementary functioning on the array
data type. On the other hand, SciPy contains all the algebraic functions some of which are there in NumPy to
some extent and not in full-fledged form.

2). Why use SciPy
SciPy is a library that uses NumPy for more mathematical functions. SciPy uses NumPy arrays as the basic data
structure, and comes with modules for various commonly used tasks in scientific programming, including linear
algebra, integration (calculus), ordinary differential equation solving, and signal processing.