file = open("34_countText.txt", "r")
cnt = 0
for word in file:
    c=word.split()
    cnt += len(c)
print(cnt)
file.close()