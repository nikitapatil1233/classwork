def letterFrequency(filename,letter):
    file = open("34_countText.txt",'r')
    text = file.read()
    return text.count(letter)

print(letterFrequency("34_countText.txt","c"))