#1). What Is a Python NumPy Array?
A numpy array is a grid of values, all of the same type, and is indexed by a tuple of nonnegative integers. The number of dimensions is the rank of the array; the shape of an array is a tuple of integers giving the size of the array along each dimension.

NumPy Arrays v/s List
A numpy array is a grid of values, all of the same type, and is indexed by a tuple of nonnegative integers A list is the Python equivalent of an array, but is resizeable and can contain elements of different types.

NumPy Operations
Mathematical and logical operation
Fourier tranforms and routines for the shape manipulation Operations related to linear algebra. Numpy has in-build functions for linear algebra and random number getion

NumPy Special Functions
numpy.cbrt(arr, out = None, ufunc ‘cbrt’) This function helps the user to conjugate any complex number. numpy.clip() This mathematical function helps user to calculate cube root of x for all x being the array elements.

convolve() Returns the discrete, linear convolution of two one-dimensional sequences. sqrt() Return the non-negative square-root of an array, element-wise. square() Return the element-wise square of the input. absolute() Calculate the absolute value element-wise. fabs() Compute the absolute values element-wise. sign() Returns an element-wise indication of the sign of a number. interp() One-dimensional linear interpolation. maximum() Element-wise maximum of array elements. minimum() Element-wise minimum of array elements. real_if_close() If complex input returns a real array if complex parts are close to zero. nan_to_num() Replace NaN with zero and infinity with large finite numbers. heaviside() Compute the Heaviside step function.