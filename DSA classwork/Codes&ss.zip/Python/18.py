# Reading an excel file using Python
import xlrd
 
# Give the location of the file
loc = ("path of file")
 
# To open Workbook
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
 
# For row 0 and column 0
print(sheet.cell_value(0, 0))
# Program to extract number
# of rows using Python
import xlrd
 
# Give the location of the file
loc = ("path of file")
 
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
sheet.cell_value(0, 0)
 
# Extracting number of rows
print(sheet.nrows)

# Program to extract number of
# columns in Python
import xlrd
 
loc = ("path of file")
 
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
 
# For row 0 and column 0
sheet.cell_value(0, 0)
 
# Extracting number of columns
print(sheet.ncols)
# Program extracting all columns
# name in Python
import xlrd
 
loc = ("path of file")
 
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
 
# For row 0 and column 0
sheet.cell_value(0, 0)
 
for i in range(sheet.ncols):
    print(sheet.cell_value(0, i))
    # Program extracting first column
import xlrd
 
loc = ("path of file")
 
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
sheet.cell_value(0, 0)
 
for i in range(sheet.nrows):
    print(sheet.cell_value(i, 0))
# Program to extract a particular row value
import xlrd
 
loc = ("path of file")
 
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
 
sheet.cell_value(0, 0)
 
print(sheet.row_values(1))