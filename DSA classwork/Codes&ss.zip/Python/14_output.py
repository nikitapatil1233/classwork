n = 150
print(n*7 if n > 500 else n/7)