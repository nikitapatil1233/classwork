import cv2
from scipy import ndimage
import numpy as np
import imageio
import matplotlib.pyplot as plt
#read the image
face1=imageio.imread('/Pictures/52-526122_nec-logo-png-clipart.png') # uses the Image module (PIL)
plt.imshow(face1)
plt.show()
#convert to greyscale
face=cv2.cvtColor(face1,cv2.COLOR_BGR2GRAY)
lx, ly = face.shape
# Cropping
crop_face = face[lx // 4: - lx // 4, ly // 4: - ly // 4]
# up <-> down flip
flip_ud_face = np.flipud(face)
# rotation
rotate_face = ndimage.rotate(face, 45)
rotate_face_noreshape = ndimage.rotate(face, 45, reshape=False)
plt.imshow(rotate_face_noreshape)