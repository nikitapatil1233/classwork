# 37. Write a Python Program to Check String is Palindrome using Stack

class Stack:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

s = Stack()
text = input("Enter a string: ")

for charecter in text:
    s.push(charecter)

reversed_text=''
while not s.isEmpty():
    reversed_text += s.pop()

if text == reversed_text:
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")