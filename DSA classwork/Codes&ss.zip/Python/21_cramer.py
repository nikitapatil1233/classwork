import numpy as np
import random    

# entries1 = list(map(int, input().split()))
# entries2 = list(map(int, input().split()))
# a = np.array(entries1).reshape(3,3)
# b = np.array(entries2).reshape(3,1)
# x = np.linalg.solve(a, b).reshape(1,3)
# print(x)


a = np.array([[6,2,-5], [3,3,-2], [7,5,-3]])
b = np.array([13,13,26])
x = np.linalg.solve(a, b)

print(x)