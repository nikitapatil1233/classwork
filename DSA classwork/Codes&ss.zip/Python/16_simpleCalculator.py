def calculator(a, b, op):
    if op == '+':
        return a + b
    elif op == '-':
        return a - b
    elif op == '*':
        return a * b
    elif op == '/':
        return a / b
    else:
        return 'Invalid operator'


a = int(input('Enter first number: '))
b = int(input('Enter second number: '))
c = input('Enter operator: ')

result = calculator(a, b, c)

print(result)